---
title: "About This Site"
hasMath: false
_build:
  list: never
---

This is the example site for [hugo-tufte](https://github.com/loikein/hugo-tufte), a theme for the static site generator [Hugo](https://gohugo.io/).
