---
title: Chapter 5. Coolest Chapter
draft: true
---
