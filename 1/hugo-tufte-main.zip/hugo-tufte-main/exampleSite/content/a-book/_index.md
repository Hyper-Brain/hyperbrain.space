---
title: Probably A Book
subtitle: Best book ever!
type: book
layout: all
draft: true
---
This is a layout showcase for:

```yaml
type: book
layout: all
```

Change `all` to `volumes` to hide chapters.

Below lists all volumes and chapters in this book alphabetically. If you see repetitions, just restart the hugo server and it should be fixed.
