---
title: Volume 1. Good Volume
type: book
layout: chapters
---
This is a layout showcase for:

```yaml
type: book
layout: chapters
```

Below lists all chapters in this volume alphabetically. If you see repetitions, just restart the hugo server and it should be fixed.
